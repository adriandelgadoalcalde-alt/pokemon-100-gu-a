using System;

namespace PKHeX.Core;

/// <summary>
/// Locations for <see cref="EntityContext.Gen8b"/>.
/// </summary>
public static class Locations8b
{
    /// <summary>
    /// HOME transfer logic maps `0` to `658` to allow the <see cref="Locations.Default8bNone"/> location to be `0` instead.
    /// </summary>
    public const ushort TransferPlaceholder0 = 658;

    /// <summary>
    /// Converts a location from BD/SP format to join the rest of the mainline games. Zero is now (None).
    /// </summary>
    /// <param name="loc">Location ID in BD/SP format.</param>
    /// <returns>Sanitized mainline location ID value.</returns>
    public static ushort GetLocationMainline(ushort loc) => loc switch
    {
        0 => TransferPlaceholder0,
        Locations.Default8bNone => 0,
        _ => loc,
    };

    /// <summary>
    /// Converts a location from mainline format to BD/SP format. Zero is now <see cref="Locations.Default8bNone"/>.
    /// </summary>
    /// <param name="loc">Location ID in mainline format.</param>
    /// <returns>Sanitized BD/SP location ID value.</returns>
    public static ushort GetLocationLocal(ushort loc) => loc switch
    {
        0 => Locations.Default8bNone,
        TransferPlaceholder0 => 0,
        _ => loc,
    };

    /// <summary>
    /// Checks if the location is a Grand Underground location.
    /// </summary>
    /// <param name="location">Location ID to check</param>
    /// <returns>True if the location is a Grand Underground location</returns>
    public static bool IsUnderground(ushort location) => location is (>= 508 and <= 617);

    /// <summary>
    /// Checks if the location is a Great Marsh location.
    /// </summary>
    /// <param name="location">Location ID to check</param>
    /// <returns>True if the location is a Great Marsh location</returns>
    public static bool IsMarsh(ushort location) => location is (>= 219 and <= 224);

    /// <summary>
    /// Available location list for the 00000 set of location names.
    /// </summary>
    public static ReadOnlySpan<ushort> Met0 =>
    [
        000, 001, 002, 003, 004, 005, 006, 007, 008, 009,
        010, 011, 012, 013, 014, 015, 016, 017, 018, 019,
        020, 021, 022, 023, 024, 025, 026, 027, 028, 029,
        030, 031, 032, 033, 034, 035, 036, 037, 038, 039,
        040, 041, 042, 043, 044, 045, 046, 047, 048, 049,
        050, 051, 052, 053, 054, 055, 056, 057, 058, 059,
        060, 061, 062, 063, 064, 065, 066, 067, 068, 069,
        070, 071, 072, 073, 074, 075, 076, 077, 078, 079,
        080, 081, 082, 083, 084, 085, 086, 087, 088, 089,
        090, 091, 092, 093, 094, 095, 096, 097, 098, 099,
        100, 101, 102, 103, 104, 105, 106, 107, 108, 109,
        110, 111, 112, 113, 114, 115, 116, 117, 118, 119,
        120, 121, 122, 123, 124, 125, 126, 127, 128, 129,
        130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
        140, 141, 142, 143, 144, 145, 146, 147, 148, 149,
        150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
        160, 161, 162, 163, 164, 165, 166, 167, 168, 169,
        170, 171, 172, 173, 174, 175, 176, 177, 178, 179,
        180, 181, 182, 183, 184, 185, 186, 187, 188, 189,
        190, 191, 192, 193, 194, 195, 196, 197, 198, 199,
        200, 201, 202, 203, 204, 205, 206, 207, 208, 209,
        210, 211, 212, 213, 214, 215, 216, 217, 218, 219,
        220, 221, 222, 223, 224, 225, 226, 227, 228, 229,
        230, 231, 232, 233, 234, 235, 236, 237, 238, 239,
        240, 241, 242, 243, 244, 245, 246, 247, 248, 249,
        250, 251, 252, 253, 254, 255, 256, 257, 258, 259,
        260, 261, 262, 263, 264, 265, 266, 267, 268, 269,
        270, 271, 272, 273, 274, 275, 276, 277, 278, 279,
        280, 281, 282, 283, 284, 285, 286, 287, 288, 289,
        290, 291, 292, 293, 294, 295, 296, 297, 298, 299,
        300, 301, 302, 303, 304, 305, 306, 307, 308, 309,
        310, 311, 312, 313, 314, 315, 316, 317, 318, 319,
        320, 321, 322, 323, 324, 325, 326, 327, 328, 329,
        330, 331, 332, 333, 334, 335, 336, 337, 338, 339,
        340, 341, 342, 343, 344, 345, 346, 347, 348, 349,
        350, 351, 352, 353, 354, 355, 356, 357, 358, 359,
        360, 361, 362, 363, 364, 365, 366, 367, 368, 369,
        370, 371, 372, 373, 374, 375, 376, 377, 378, 379,
        380, 381, 382, 383, 384, 385, 386, 387, 388, 389,
        390, 391, 392, 393, 394, 395, 396, 397, 398, 399,
        400, 401, 402, 403, 404, 405, 406, 407, 408, 409,
        410, 411, 412, 413, 414, 415, 416, 417, 418, 419,
        420, 421, 422, 423, 424, 425, 426, 427, 428, 429,
        430, 431, 432, 433, 434, 435, 436, 437, 438, 439,
        440, 441, 442, 443, 444, 445, 446, 447, 448, 449,
        450, 451, 452, 453, 454, 455, 456, 457, 458, 459,
        460, 461, 462, 463, 464, 465, 466, 467, 468, 469,
        470, 471, 472, 473, 474, 475, 476, 477, 478, 479,
        480, 481, 482, 483, 484, 485, 486, 487, 488, 489,
        490, 491, 492, 493, 494, 495, 496, 497, 498, 499,
        500, 501, 502, 503, 504, 505, 506, 507, 508, 509,
        510, 511, 512, 513, 514, 515, 516, 517, 518, 519,
        520, 521, 522, 523, 524, 525, 526, 527, 528, 529,
        530, 531, 532, 533, 534, 535, 536, 537, 538, 539,
        540, 541, 542, 543, 544, 545, 546, 547, 548, 549,
        550, 551, 552, 553, 554, 555, 556, 557, 558, 559,
        560, 561, 562, 563, 564, 565, 566, 567, 568, 569,
        570, 571, 572, 573, 574, 575, 576, 577, 578, 579,
        580, 581, 582, 583, 584, 585, 586, 587, 588, 589,
        590, 591, 592, 593, 594, 595, 596, 597, 598, 599,
        600, 601, 602, 603, 604, 605, 606, 607, 608, 609,
        610, 611, 612, 613, 614, 615, 616, 617, 618, 619,
        620, 621, 622, 623, 624, 625, 626,

        // Skip the secret base met location IDs because no Pokémon can be obtained in them.

        // Ramanas Park rooms with lights out
        648, 649, 650, 651, 652, 653, 654, 655, 656, 657,
    ];

    /// <summary>
    /// Available location list for the 30000 set of location names.
    /// </summary>
    public static ReadOnlySpan<ushort> Met3 =>
    [
               30001,        30003, 30004, 30005, 30006, 30007,        30009,
        30010, 30011, 30012, 30013, 30014, 30015, 30016, 30017, 30018, 30019,
        30020,        30022,
    ];

    /// <summary>
    /// Available location list for the 40000 set of location names.
    /// </summary>
    public static ReadOnlySpan<ushort> Met4 =>
    [
        40001, 40002, 40003, 40005, 40006, 40007, 40008, 40009,
        40010, 40011, 40012, 40013, 40014, 40016, 40017, 40018, 40019,
        40020, 40021, 40022, 40024, 40025, 40026, 40027, 40028, 40029,
        40030, 40032, 40033, 40034, 40035, 40036, 40037, 40038, 40039,
        40040, 40041, 40042, 40043, 40044, 40045, 40047, 40048, 40049,
        40050, 40051, 40052, 40053, 40055, 40056, 40057, 40058, 40059,
        40060, 40061, 40063, 40064, 40065, 40066, 40067, 40068, 40069,
        40070, 40071, 40072, 40074, 40075, 40076, 40077, 40078, 40079,
        40080, 40081, 40082, 40083, 40084, 40085, 40086,
    ];

    /// <summary>
    /// Available location list for the 60000 set of location names.
    /// </summary>
    public static ReadOnlySpan<ushort> Met6 => [/* X/Y */ 60001, 60003, /* OR/AS */ 60004, /* BD/SP */ 60005, 60006, 60007, 60010];
}
