using System.Collections.Generic;
using static PKHeX.Core.GameVersion;

namespace PKHeX.Core;

public sealed class EncounterGenerator8X : IEncounterGenerator
{
    public static readonly EncounterGenerator8X Instance = new();
    public bool CanGenerateEggs => false;

    public IEnumerable<IEncounterable> GetPossible(PKM pk, EvoCriteria[] chain, GameVersion version, EncounterTypeGroup groups) => version switch
    {
        GO => EncounterGenerator8GO.Instance.GetPossible(pk, chain, version, groups),
        PLA => EncounterGenerator8a.Instance.GetPossible(pk, chain, version, groups),
        BD or SP => EncounterGenerator8b.Instance.GetPossible(pk, chain, version, groups),
        _ => EncounterGenerator8.Instance.GetPossible(pk, chain, version, groups),
    };

    public IEnumerable<IEncounterable> GetEncounters(PKM pk, LegalInfo info)
    {
        var context = pk.Version switch
        {
            PLA => EntityContext.Gen8a,
            BD or SP => EntityContext.Gen8b,
            _ => EntityContext.Gen8,
        };
        var chain = EncounterOrigin.GetOriginChain(pk, 8, context);
        return GetEncounters(pk, chain, info);
    }

    public IEnumerable<IEncounterable> GetEncounters(PKM pk, EvoCriteria[] chain, LegalInfo info) => pk.Version switch
    {
        GO => EncounterGeneratorGO.Instance.GetEncounters(pk, chain, info),
        PLA      when pk is not PK8 => EncounterGenerator8a.Instance.GetEncounters(pk, chain, info),
        BD or SP when pk is not PK8 => EncounterGenerator8b.Instance.GetEncounters(pk, chain, info),
        SW => pk.MetLocation switch
        {
            LocationsHOME.SWLA => EncounterGenerator8a.Instance.GetEncounters(pk, chain, info),
            LocationsHOME.SWBD => EncounterGenerator8b.Instance.GetEncountersSWSH(pk, chain, BD),
            LocationsHOME.SWSL => EncounterGenerator9.Instance.GetEncountersSWSH(pk, chain, SL),
            LocationsHOME.SWFR when pk is PK8 => EncounterGenerator3.Instance.GetEncounters(pk, chain, info, FRX),
            _ => EncounterGenerator8.Instance.GetEncounters(pk, chain, info),
        },
        SH => pk.MetLocation switch
        {
            LocationsHOME.SHSP => EncounterGenerator8b.Instance.GetEncountersSWSH(pk, chain, SP),
            LocationsHOME.SHVL => EncounterGenerator9.Instance.GetEncountersSWSH(pk, chain, VL),
            LocationsHOME.SHLG when pk is PK8 => EncounterGenerator3.Instance.GetEncounters(pk, chain, info, LGX),
            _ => EncounterGenerator8.Instance.GetEncounters(pk, chain, info),
        },
        _ => [],
    };
}
